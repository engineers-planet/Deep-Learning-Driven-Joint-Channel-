# ==========================================================================
#    This UWOC-JCCESD code is used for the joint channel classification
#    and estimation with signal detection (JCCESD) scheme in
#    underwater wireless optical communication (UWOC) systems.
#
#    Copyright (C) <2020>  <Huaiyin Lu>
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    If you use and/or modify this program for further researches and/or
#    applications, please cite the reference paper as follows, which proposes
#    the JCCESD scheme.
#
#    H. Lu, M. Jiang, and J. Cheng, ``Deep learning aided robust joint channel
#    classification, channel estimation, and signal detection for underwater
#    optical communication'', IEEE Trans. Commun., 2020.
#    BibTex: @ARTICLE{Lu2020j-UWOC-JCCESD,
#    Title={{Deep learning aided robust joint channel classification, channel estimation, and signal detection for underwater optical communication}},
#    Author={H. Lu and M. Jiang and J. Cheng},
#    Journal={{IEEE Trans. Commun.}},
#    Year={2020}
#    }
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
#    Author: Huaiyin Lu
#    Affiliation: Sun Yat-sen University, Guangzhou, China
#    Version: 0.1
#    Upload date: Dec. 07, 2020
#    E-mail: 513284310@qq.com
# ==========================================================================

# This file is the procedure of training DNN-CC reflecting to Section III-C.4.

import numpy as np
import pandas as pd
from keras.callbacks import EarlyStopping, ReduceLROnPlateau, ModelCheckpoint, TensorBoard
from keras.optimizers import RMSprop, Adam
from model.classifier_losses import loss_classify
from keras.utils import multi_gpu_model


from keras import *
import h5py

import warnings
warnings.filterwarnings("ignore")
import params_classify

import os
os.environ["CUDA_VISIBLE_DEVICES"] = "1"

epochs = params_classify.max_epochs
batch_size = params_classify.batch_size

tur_num=2

#DNN weight path
weight='weights/classifier.hdf5'



# Training different SNRs of sigma^2_I=0.1
for my_db in range(6):
    db = '{}db'.format(20 + my_db * 10)  # different training sets of different SNRs

    if my_db == 2:    # the final training
        epochs = 1000

    my_dir = 'data/0.1/'

# load training set
    df_train = pd.read_csv('data/0.1/'+'train_{}'.format(db)+'_input_mix_type.csv')
    train = df_train.values[:, 1:]
    train = np.expand_dims(train, axis=2)


    df_output = pd.read_csv('data/0.1/' + '/'+'train_{}'.format(db)+'_output_type.csv')
    train_output = df_output.values[:, 1:]



    model = params_classify.model_factory()
    if my_db != 0:   # training on the previous model
        model.load_weights(filepath=weight)

    # callbacks
    callbacks = [EarlyStopping(monitor='loss',
                           patience=9,
                           verbose=1,
                           min_delta=1e-4),
             ReduceLROnPlateau(monitor='loss',
                               factor=0.1,
                               patience=3,
                               verbose=1,
                               epsilon=1e-4,
                               mode='min'),
             ModelCheckpoint(monitor='loss',
                             filepath=weight,
                             save_best_only=True,
                             save_weights_only=True),
             TensorBoard(log_dir='logs')]

    model.compile(optimizer=Adam(lr=0.001), metrics=['accuracy'], loss=loss_classify)
    model.fit(train,train_output,epochs=epochs,batch_size=batch_size,verbose=1,callbacks=callbacks)


# Training different turbulence sigma^2_I=[0.5,0.8,1]
tur = np.array([0.5, 0.8, 1])

for tur_label in range(3):
    db = '{}db'.format(70)  # 70dB training set

    epochs = 1000

    tur_path = tur[tur_label]
    if tur_label == 1:
        tur_path = int(tur_path)

    # load training set
    df_train = pd.read_csv('data/' + '{}/'.format(tur_path) + 'train_{}_input'.format(db) +'_input_mix_type.csv')
    train = df_train.values[:, 1:]
    train = np.expand_dims(train, axis=2)
    df_output = pd.read_csv('data/' + '{}/'.format(tur_path) + 'train_{}_output'.format(db) +'_output_mix_type.csv')
    train_output = df_output.values[:, 1:]



    # load model
    model = params_classify.model_factory()

    model.load_weights(filepath=weight) # training on the previous model

    # callbacks
    callbacks = [EarlyStopping(monitor='loss',
                           patience=9,
                           verbose=1,
                           min_delta=1e-4),
             ReduceLROnPlateau(monitor='loss',
                               factor=0.1,
                               patience=3,
                               verbose=1,
                               epsilon=1e-4,
                               mode='min'),
             ModelCheckpoint(monitor='loss',
                             filepath=weight,
                             save_best_only=True,
                             save_weights_only=True),
             TensorBoard(log_dir='logs')]

    model.compile(optimizer=Adam(lr=0.001), metrics=['accuracy'], loss=loss_classify)
    model.fit(train,train_output,epochs=epochs,batch_size=batch_size,verbose=1,callbacks=callbacks)
