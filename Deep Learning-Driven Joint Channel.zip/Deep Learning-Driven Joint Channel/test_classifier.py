# ==========================================================================
#    This UWOC-JCCESD code is used for the joint channel classification
#    and estimation with signal detection (JCCESD) scheme in
#    underwater wireless optical communication (UWOC) systems.
#
#    Copyright (C) <2020>  <Huaiyin Lu>
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    If you use and/or modify this program for further researches and/or
#    applications, please cite the reference paper as follows, which proposes
#    the JCCESD scheme.
#
#    H. Lu, M. Jiang, and J. Cheng, ``Deep learning aided robust joint channel
#    classification, channel estimation, and signal detection for underwater
#    optical communication'', IEEE Trans. Commun., 2020.
#    BibTex: @ARTICLE{Lu2020j-UWOC-JCCESD,
#    Title={{Deep learning aided robust joint channel classification, channel estimation, and signal detection for underwater optical communication}},
#    Author={H. Lu and M. Jiang and J. Cheng},
#    Journal={{IEEE Trans. Commun.}},
#    Year={2020}
#    }
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
#    Author: Huaiyin Lu
#    Affiliation: Sun Yat-sen University, Guangzhou, China
#    Version: 0.1
#    Upload date: Dec. 07, 2020
#    E-mail: 513284310@qq.com
# ==========================================================================

# This file is the procedure of generating ECW reflecting to Section III-C.4.

import numpy as np
import pandas as pd
from keras.callbacks import EarlyStopping, ReduceLROnPlateau, ModelCheckpoint, TensorBoard
# from sklearn.model_selection import train_test_split
from keras import *
import copy
import h5py
import warnings

warnings.filterwarnings("ignore")
import params_classify

import time
import os

os.environ["CUDA_VISIBLE_DEVICES"] = "0"
import tensorflow as tf
import keras.backend as K

epochs = params_classify.max_epochs
batch_size = params_classify.batch_size

# DNN weight path
weight = 'weights/classifier.hdf5'

# testing data set path
my_dir = 'data/0.1/'
my_dir2 = '_type3'
my_dir3 = '.csv'

for my_db in range(6):
    file_name = '{}db'.format(20 + my_db * 10)

    # load testing set
    test_0db_input = pd.read_csv(my_dir + 'test_{}_input'.format(file_name) + my_dir2 + my_dir3)
    test = test_0db_input.values[:, 1:]
    test = np.expand_dims(test, axis=2)
    test_0db_output = pd.read_csv(my_dir + 'test_{}_output'.format(file_name) + my_dir2 + my_dir3)
    test_output = test_0db_output.values[:, 1:]

    weight_vector = np.ones((1, 4))
    # load model and weights
    model = params_classify.model_factory()
    model.load_weights(filepath=weight)

    # predict ECW
    predict = model.predict(test)
    weight_vector[0, :] = np.mean(predict, axis=0)

    df = pd.DataFrame(weight_vector)
    df.to_csv('ECW/ECW' + my_dir2 + '{}_weight.csv'.format(file_name), index=False)



