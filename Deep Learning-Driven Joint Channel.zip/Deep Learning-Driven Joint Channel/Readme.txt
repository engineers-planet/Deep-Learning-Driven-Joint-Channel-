System: Linux version 4.4.98-040498-generic (kernel@gloin) (gcc version 5.4.0 20160609 (Ubuntu 5.4.0-6ubuntu1~16.04.4) )

GPU: GTX1080Ti

Software: Pycharm

Environment: Python 3.6, Keras 2.2.2, Tensorflow 1.9.0

Reference: H. Lu, M. Jiang, and J. Cheng, ``Deep learning aided robust joint channel classification, channel estimation, and signal detection for underwater optical communication'', IEEE Trans. Commun., 2020.



Promgram steps:




1.Data generation



1.1 Data sets are generated in UWOC system in Fig.1 with CIR data. In data generation, we collect Y as input, b as output for training. 

1.2 The data sets are saved as .csv files. In data generation process, 10^5 vectors are collected for each of the M=4 training water types of each SNR={20,30,40,50,60,70}dB. More specifically, there are 4*6=24 input data sets and 4*6=24 output data sets for 4  water types and 6 SNR levels. The size of each input data set Y is 10^5*256. The size of each output data set is 10^5*62. 




1.3 Each row of Y is a 1*256 input vector illustrated in Table III. Each row of b is a 1*62 output vector that is the transmitted bit vector corresponding to the same row of Y.

1.4 Testing data sets can be generated in the same way as training data sets.


2.DNN detector training and testing



2.1 In detector training process, we run "train_detector.py" for M=4 detectors where data set 

Y is input and b is output.

2.2 The BER performance can be calculated by running "test_detector.py" with testing data sets.



3.Classifier training and testing



3.1 We merge 4 water type training data sets generated from 1.1 as the training data sets of classifier of each SNR={20,30,40,50,60,70}dB. The size of each input data set is (4*10^5)*256. 


3.2 We run "test_for_predict.py" on mixed input data sets in 3.1 with 4 trained detetectors to generating \mathbf{\tilde{Q}}_1 to \mathbf{\tilde{Q}}_4 in Fig.5. The size of \mathbf{\tilde{Q}}_i is (4*10^5)*62.  



3.3 We merge TCW in equation (22), \mathbf{\tilde{Q}}_1 to \mathbf{\tilde{Q}}_4 in 3.2 and transmitted bit b in column splicing to form a 4+62*4+62(4:TCW,62*4:\mathbf{\tilde{Q}}_1 to \mathbf{\tilde{Q}}_4,62:transmitted bit b) vector of each row which is the row vector of output training set of the classifier. The size of the output data set is (4*10^5)*(4+62*4+62).



3.4 We apply input data set in 3.1 and output data sets in 3.3 to run "train_classifier.py" for training classifier.


3.5 We run "test_classifier.py" with testing data sets of untrained water types to get ECW.

3.6 We run "test_combine_ECW_to_bit.py" with testing data sets of untrained water types to get JCCESD BER performance with ECW in 3.5.



 
